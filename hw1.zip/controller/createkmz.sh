#!/bin/bash
zip -r myfile.zip files myfile.kml
mv myfile.zip myfile.kmz